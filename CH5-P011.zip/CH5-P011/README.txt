SBL 1.0 resolved page rendering package
Render target: CH5-P011
Entry file: CH5-P011.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Six-Schools-symbols-and-diagrams-production-sheet.png
  Assets/Zoran_Language_and_script.docx
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Zora-mana-effects-sheet.png
  Assets/Recurring-Population-and-Costume-Sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Zoran-research-laboratory-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
