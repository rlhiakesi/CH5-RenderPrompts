SBL 1.0 resolved page rendering package
Render target: CH5-P015
Entry file: CH5-P015.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Nyssara-canonical-character-specification.txt
  Assets/WOA-canonical-production-specification.txt
  Assets/WOA-time-compression-display-specification.txt
  Assets/Transmutation-Scientific-Method-Technical-Sheet.png
  Assets/Recurring-Population-and-Costume-Sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Zora-cultural-development-specification.txt
  Assets/Nyssara-expression-sheet.png
  Assets/WOA-production-sheet-plus-map.png
  Assets/Nyssara-character-sheet.png
  Assets/WOA-production-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Zorna-expression-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zorna-character-sheet.png
  Assets/WOA-observation-field-states-sheet.png
  Assets/Terra-canonical-character-specification.txt
  Assets/Zoran-research-laboratory-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
