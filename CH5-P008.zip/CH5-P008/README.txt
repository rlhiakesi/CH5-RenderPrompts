SBL 1.0 resolved page rendering package
Render target: CH5-P008
Entry file: CH5-P008.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Jeremiel-canonical-character-specification.txt
  Assets/Mage-Corps-Training-and-Field-Equipment-Sheet.png
  Assets/Jeremiel-expression-sheet.png
  Assets/Recurring-Population-and-Costume-Sheet.png
  Assets/Jeremiel-character-sheet.png
  Assets/Six-Schools-symbols-and-diagrams-production-sheet.png
  Assets/Jeremiel-Elderly-Frail-Character-Sheet.png
  Assets/Zora-mana-effects-sheet.png
  Assets/Zoran-research-laboratory-production-sheet.png
  Assets/Zora-cultural-development-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
